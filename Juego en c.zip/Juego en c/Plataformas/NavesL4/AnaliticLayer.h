#pragma once
#include "Layer.h"
#include "Background.h"
#include "Text.h"

class AnaliticLayer : public Layer
{
public:
	AnaliticLayer(Game* game, bool drugs);
	void init() override;
	void draw() override;
	void processControls() override;
	void mouseToControls(SDL_Event event);
	void keysToControls(SDL_Event event);

	Background* background;
	Actor* mouthPhoto;

	Text* back;
	Actor* backButton;

	Actor* swab;

	Actor* mouth;

	bool drugs;

};

