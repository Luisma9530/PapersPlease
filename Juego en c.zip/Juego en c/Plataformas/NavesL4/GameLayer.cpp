#include "GameLayer.h"

GameLayer::GameLayer(Game* game)
	: Layer(game) {
	//llama al constructor del padre : Layer(renderer)
	pause = true;
	message = new Actor("res/mensaje_como_jugar.png", WIDTH * 0.5, HEIGHT * 0.5,
		WIDTH, HEIGHT, game);

	init();
}

void GameLayer::init() {
	generator = new PersonGenerator();
	generator->generateRandomPerson();

	audioBackground = Audio::createAudio("res/main_theme.mp3", true);
	audioBackground->play();

	marco = new Actor("res/marco.png",
		WIDTH * 0.3, HEIGHT * 0.45, 400, 450, game);
	
	photo = new Actor(generator->obtenerRutaImagen(generator->generatedPerson->gender),
		WIDTH * 0.375, HEIGHT * 0.275, 90, 90, game);

	accept = new Text("Aceptar", WIDTH * 0.6, HEIGHT * 0.7, game);
	acceptButton = new Actor("res/verde.png",
		WIDTH * 0.6, HEIGHT * 0.7, 180, 90, game);

	deny = new Text("Denegar", WIDTH * 0.75, HEIGHT * 0.7, game);
	denyButton = new Actor("res/rojo.png",
		WIDTH * 0.75, HEIGHT * 0.7, 180, 90, game);

	scanner = new Text("Escaner", WIDTH * 0.75, HEIGHT * 0.55, game);
	scannerButton = new Actor("res/gris.png",
		WIDTH * 0.75, HEIGHT * 0.55, 180, 90, game);

	drugTest = new Text("Anal�tica", WIDTH * 0.75, HEIGHT * 0.4, game);
	drugTestButton = new Actor("res/gris.png",
		WIDTH * 0.75, HEIGHT * 0.4, 180, 90, game);

	textName = new Text("Cargando...", WIDTH * 0.3, HEIGHT * 0.425, game);
	textAge = new Text("Cargando...", WIDTH * 0.3, HEIGHT * 0.475, game);
	textGender = new Text("Cargando...", WIDTH * 0.3, HEIGHT * 0.525, game);
	textWeight = new Text("Cargando...", WIDTH * 0.3, HEIGHT * 0.575, game);
	textDate = new Text("Cargando...", WIDTH * 0.3, HEIGHT * 0.625, game);
	textName->content = "Nombre: " + generator->secondaryPerson->name;
	textAge->content = "Edad: " + std::to_string(generator->secondaryPerson->age);
	if (generator->secondaryPerson->gender) {
		textGender->content = "Genero: M";
	}
	else {
		textGender->content = "Genero: F";
	}
	textWeight->content = "Peso: " + std::to_string(generator->secondaryPerson->weight);

	textDate->content = "Fecha de caducidad: " + 
		std::to_string(generator->secondaryPerson->date.tm_mday) + "/" +
		std::to_string(generator->secondaryPerson->date.tm_mon) + "/" +
		std::to_string(generator->secondaryPerson->date.tm_year);

	textRealWeight = new Text("Cargando...", WIDTH * 0.8, HEIGHT * 0.22, game);

	textRealWeight->content = "V�scula: " + std::to_string(generator->generatedPerson->weight) + "kg";

	today = new Text("Cargando...", WIDTH * 0.8, HEIGHT * 0.17, game);

	auto currentTime = std::chrono::system_clock::now();

	std::time_t currentTime_t = std::chrono::system_clock::to_time_t(currentTime);
	std::tm localTime;
	if (localtime_s(&localTime, &currentTime_t) == 0) {
		today->content = "6/7/60-" + std::to_string(localTime.tm_hour) + ":" 
			+ std::to_string(localTime.tm_min);
	}
	else {
		today->content = "6/7/60";
	}

	successes = new Text("Cargando...", WIDTH * 0.06, HEIGHT * 0.05, game);
	successes->content = "Aciertos: " + std::to_string(points);

	wrong = new Text("Cargando...", WIDTH * 0.05, HEIGHT * 0.1, game);
	wrong->content = "Fallos: " + std::to_string(fails);

	background = new Background("res/garita.png", WIDTH * 0.5, HEIGHT * 0.5, 0, game);
}


void GameLayer::processControls() {
	// obtener controles
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		// Cambio autom�tico de input
		if (event.type == SDL_CONTROLLERBUTTONDOWN || event.type == SDL_CONTROLLERAXISMOTION) {
			game->input = game->inputGamePad;
		}
		if (event.type == SDL_KEYDOWN) {
			game->input = game->inputKeyboard;
		}
		if (event.type == SDL_MOUSEBUTTONDOWN) {
			game->input = game->inputMouse;
		}
		// Procesar teclas
		if (game->input == game->inputKeyboard) {
			keysToControls(event);
		}
		if (game->input == game->inputMouse) {
			mouseToControls(event);
		}

		if (controlContinue) {
			pause = false;
			controlContinue = false;
		}
	}
}

void GameLayer::update() {
	if (pause) {
		return;
	}

	auto currentTime = std::chrono::system_clock::now();

	std::time_t currentTime_t = std::chrono::system_clock::to_time_t(currentTime);
	std::tm localTime;
	if (localtime_s(&localTime, &currentTime_t) == 0) {
		today->content = "6/7/60-" + std::to_string(localTime.tm_hour) + ":"
			+ std::to_string(localTime.tm_min);
	}
	else {
		today->content = "6/7/60";
	}

	background->update();
}

void GameLayer::updatePerson() {
	generator->generateRandomPerson();
	photo = new Actor(generator->obtenerRutaImagen(generator->generatedPerson->gender),
		WIDTH * 0.375, HEIGHT * 0.3, 90, 90, game);
	textName->content = "Nombre: " + generator->secondaryPerson->name;
	textAge->content = "Edad: " + std::to_string(generator->secondaryPerson->age);
	if (generator->secondaryPerson->gender) {
		textGender->content = "Genero: M";
	}
	else {
		textGender->content = "Genero: F";
	}

	textDate->content = "Fecha de caducidad: " +
		std::to_string(generator->secondaryPerson->date.tm_mday) + "/" +
		std::to_string(generator->secondaryPerson->date.tm_mon) + "/" +
		std::to_string(generator->secondaryPerson->date.tm_year);

	textWeight->content = "Peso: " + std::to_string(generator->secondaryPerson->weight) + "kg";

	textRealWeight->content = "V�scula: " + std::to_string(generator->generatedPerson->weight) + "kg";
}

void GameLayer::draw() {

	background->draw();

	marco->draw();
	photo->draw();

	acceptButton->draw();
	accept->draw();

	denyButton->draw();
	deny->draw();

	scannerButton->draw();
	scanner->draw();

	drugTestButton->draw();
	drugTest->draw();

	textName->draw();
	textAge->draw();
	textGender->draw();
	textWeight->draw();
	textDate->draw();
	today->draw();

	successes->draw();
	wrong->draw();

	textRealWeight->draw();

	if (pause) {
		message->draw();
	}

	SDL_RenderPresent(game->renderer); // Renderiza
}


void GameLayer::mouseToControls(SDL_Event event) {
	// Modificaci�n de coordenadas por posible escalado
	float motionX = event.motion.x / game->scaleLower;
	float motionY = event.motion.y / game->scaleLower;
	// Cada vez que hacen click
	if (event.type == SDL_MOUSEBUTTONDOWN) {
		controlContinue = true;
		if (acceptButton->containsPoint(motionX, motionY)) {
			if (!generator->modifiedPerson) {
				points++;
			}
			else {
				fails++;
			}
			wrong->content = "Fallos: " + std::to_string(fails);
			successes->content = "Aciertos: " + std::to_string(points);
			updatePerson();
		}
		if (denyButton->containsPoint(motionX, motionY)) {
			if (generator->modifiedPerson) {
				points++;
			}
			else {
				fails++;
			}
			wrong->content = "Fallos: " + std::to_string(fails);
			successes->content = "Aciertos: " + std::to_string(points);
			updatePerson();
		}
		if (scannerButton->containsPoint(motionX, motionY)) {
			game->layer = new ScannerLayer(game, generator->secondaryPerson->ilegalItem);
		}
		if (drugTestButton->containsPoint(motionX, motionY)) {
			game->layer = new AnaliticLayer(game, generator->secondaryPerson->drugs);
		}
	}
	// Cada vez que se mueve
	if (event.type == SDL_MOUSEMOTION) {

	}
	// Cada vez que levantan el click
	if (event.type == SDL_MOUSEBUTTONUP) {

	}
}


void GameLayer::keysToControls(SDL_Event event) {
	if (event.type == SDL_KEYDOWN) {
		int code = event.key.keysym.sym;
		// Pulsada
		switch (code) {
		case SDLK_ESCAPE:
			game->loopActive = false;
			break;
		}


	}
	if (event.type == SDL_KEYUP) {
		int code = event.key.keysym.sym;
		// Levantada
		switch (code) {

		}

	}

}

