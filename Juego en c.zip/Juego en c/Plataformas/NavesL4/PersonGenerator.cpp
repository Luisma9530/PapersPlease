#include "PersonGenerator.h"
#include <cstdlib>

PersonGenerator::PersonGenerator() {
    srand(time(0));
    modifiedPerson = false;
    nombresHombre = {
        "Juan", "Pedro", "Carlos", "Miguel", "Alejandro",
        "Luis", "Javier", "Roberto", "Jos�", "Andr�s",
        "Fernando", "Daniel", "Alberto", "Ricardo", "Gabriel",
        "Santiago", "Ra�l", "H�ctor", "Mario", "Eduardo"
    };
    nombresMujer = {
    "Mar�a", "Ana", "Laura", "Isabel", "Elena",
    "Sof�a", "Carmen", "Luisa", "Patricia", "Rosa",
    "Clara", "Beatriz", "Marta", "Victoria", "Juana",
    "Antonia", "Diana", "Natalia", "Raquel", "Cristina"
    };
}

Person* PersonGenerator::generateRandomPerson() {
    modifiedPerson = false;
    // Generar atributos al azar
    bool gender = generateRandomGender();
    string nombre = generateRandomName(gender);
    int age = generateRandomAge();
    
    int weight = generateRandomWeight();
    bool illegalItem = false;
    bool drugs = false;
    std::tm birthDate = generateRandomDateAfter();

    // Crear instancia de la clase Person con atributos al azar
    Person* randomPerson = new Person(nombre, age, gender, weight, 
        illegalItem, drugs, birthDate);
    generatedPerson = randomPerson;
    secondaryPerson = new Person(generatedPerson->name, generatedPerson->age,
        generatedPerson->gender, generatedPerson->weight, generatedPerson->ilegalItem,
        generatedPerson->drugs, generatedPerson->date);

    int probabilidad = std::rand() % 100 + 1;
    if (probabilidad <= 25) {
        modifyRandomAttribute();
    }
    return randomPerson;
}

string PersonGenerator::generateRandomName(bool gender) {
    const std::vector<std::string>& listaFotos = gender ? nombresHombre : nombresMujer;

    int indiceAleatorio = rand() % listaFotos.size();

    return listaFotos[indiceAleatorio];
}

int PersonGenerator::generateRandomAge() {
    // Generar edad aleatoria entre 18 y 100
    return rand() % 82 + 18;
}

bool PersonGenerator::generateRandomGender() {
    // Generar g�nero aleatorio (true para masculino, false para femenino)
    return rand() % 2 == 0;
}

int PersonGenerator::generateRandomWeight() {
    // Generar peso aleatorio entre 40 y 90
    return rand() % 51 + 40;
}

std::tm PersonGenerator::generateRandomDateAfter() {
    std::tm randomDate;

    // Establecer la fecha m�nima a 7 de agosto de 1960
    randomDate.tm_year = 60; // El a�o en std::tm es el a�o actual menos 1900
    randomDate.tm_mon = 7;  // 7 representa agosto
    randomDate.tm_mday = rand() % 25 + 7;  // Entre el 7 y el 31 de agosto

    // Establecer horas, minutos y segundos a cero
    randomDate.tm_hour = 0;
    randomDate.tm_min = 0;
    randomDate.tm_sec = 0;

    return randomDate;
}

std::tm PersonGenerator::generateRandomDateBefore() {
    std::tm randomDate;

    // Establecer la fecha m�nima a 1956
    randomDate.tm_year = 56; // El a�o en std::tm es el a�o actual menos 1900
    randomDate.tm_mon = rand() % 12; // Mes aleatorio

    // Generar d�a aleatorio, asegur�ndose de que sea v�lido para el mes
    int maxDay = 31;  // Establecer un valor predeterminado (m�ximo para la mayor�a de los meses)
    if (randomDate.tm_mon == 3 || randomDate.tm_mon == 5 || randomDate.tm_mon == 8 || randomDate.tm_mon == 10) {
        maxDay = 30;  // Abril, junio, septiembre, noviembre tienen 30 d�as
    }
    else if (randomDate.tm_mon == 1) {
        maxDay = 28;  // Febrero tiene 28 d�as (ignorando a�os bisiestos por simplicidad)
    }

    randomDate.tm_mday = rand() % maxDay + 1; // D�a aleatorio

    // Si el a�o es 1960, aseg�rate de que la fecha no sea despu�s del 6 de agosto
    if (randomDate.tm_year == 60) {
        randomDate.tm_mon = std::min(randomDate.tm_mon, 7); // 7 representa agosto
        randomDate.tm_mday = std::min(randomDate.tm_mday, 6);
    }

    // Establecer horas, minutos y segundos a cero
    randomDate.tm_hour = 0;
    randomDate.tm_min = 0;
    randomDate.tm_sec = 0;

    return randomDate;
}

string PersonGenerator::obtenerRutaImagen(bool gender) {
    // Obtener un n�mero aleatorio entre 1 y 11
    int numeroAleatorio = rand() % 11 + 1;

    // Construir la ruta de la imagen basada en el g�nero y el n�mero aleatorio
    std::string rutaBase = gender ? "res/hombre" : "res/mujer";
    std::string rutaImagen = rutaBase + std::to_string(numeroAleatorio) + ".png";

    return rutaImagen;
}

void PersonGenerator::modifyRandomAttribute() {
    // Generar un n�mero aleatorio para seleccionar un atributo al azar
    int randomAttribute = rand() % 5; // 0 a 4 (5 atributos en total)
    modifiedPerson = true;
    cout << "------------------------Fallo------------------------" << endl;
    cout << randomAttribute << endl;
    // Modificar el atributo seleccionado
    switch (randomAttribute) {
    case 0:
        secondaryPerson->date = generateRandomDateBefore();
        break;
    case 1:
        secondaryPerson->gender = !secondaryPerson->gender;
        secondaryPerson->name = generateRandomName(secondaryPerson->gender);
        break;
    case 2:
        secondaryPerson->weight = generateRandomWeight();
        break;
    case 3:
        secondaryPerson->ilegalItem = !secondaryPerson->ilegalItem;
        break;
    case 4:
        secondaryPerson->drugs = !secondaryPerson->drugs;
        break;
    }
}

