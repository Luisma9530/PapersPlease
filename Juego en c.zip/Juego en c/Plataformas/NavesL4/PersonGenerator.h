#pragma once

#include "Person.h"
#include <vector>

class PersonGenerator
{
public:
	PersonGenerator();
	Person* generateRandomPerson();
	string generateRandomName(bool gender);
	int generateRandomAge();
	bool generateRandomGender();
	int generateRandomWeight();
	void modifyRandomAttribute();
	std::tm generateRandomDateAfter();
	std::tm generateRandomDateBefore();
	string obtenerRutaImagen(bool gender);

	std::vector<std::string> nombresHombre;
	std::vector<std::string> nombresMujer;
	Person* generatedPerson = NULL;
	Person* secondaryPerson = NULL;
	bool modifiedPerson;
};

