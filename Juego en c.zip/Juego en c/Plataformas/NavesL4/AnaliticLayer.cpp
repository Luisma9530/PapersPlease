#include "AnaliticLayer.h"

AnaliticLayer::AnaliticLayer(Game* game, bool drugs)
	: Layer(game) {

	this->drugs = drugs;

	init();
}

void AnaliticLayer::init() {
	background = new Background("res/fondoEscaner.png", WIDTH * 0.5, HEIGHT * 0.5, game);

	mouthPhoto = new Actor("res/boca.png",
		WIDTH * 0.5, HEIGHT * 0.5, 867, 671, game);

	back = new Text("Volver", WIDTH * 0.9, HEIGHT * 0.9, game);
	backButton = new Actor("res/gris.png",
		WIDTH * 0.9, HEIGHT * 0.9, 180, 90, game);

	swab = new Actor("res/bastoncillo.png",
		WIDTH * 0.5, HEIGHT * 0.5, 180, 180, game);

	mouth = new Actor("res/boton_invisible.png",
		WIDTH * 0.52, HEIGHT * 0.375, 240, 290, game);
}

void AnaliticLayer::draw() {
	background->draw();
	mouthPhoto->draw();

	backButton->draw();
	back->draw();

	mouth->draw();

	swab->draw();

	SDL_RenderPresent(game->renderer);
}

void AnaliticLayer::processControls() {
	// obtener controles
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		// Cambio autom�tico de input
		if (event.type == SDL_CONTROLLERBUTTONDOWN || event.type == SDL_CONTROLLERAXISMOTION) {
			game->input = game->inputGamePad;
		}
		if (event.type == SDL_KEYDOWN) {
			game->input = game->inputKeyboard;
		}
		if (event.type == SDL_MOUSEBUTTONDOWN) {
			game->input = game->inputMouse;
		}
		// Procesar teclas
		if (game->input == game->inputKeyboard) {
			keysToControls(event);
		}
		if (game->input == game->inputMouse) {
			mouseToControls(event);
		}

	}
}

void AnaliticLayer::mouseToControls(SDL_Event event) {
	// Modificaci�n de coordenadas por posible escalado
	float motionX = event.motion.x / game->scaleLower;
	float motionY = event.motion.y / game->scaleLower;

	// Cada vez que hacen click
	if (event.type == SDL_MOUSEBUTTONDOWN) {
		if (backButton->containsPoint(motionX, motionY)) {
			game->layer = game->gameLayer;
		}
		if (mouth->containsPoint(motionX, motionY) && drugs) {
			swab->texture = game->getTexture("res/bastoncilloAzul.png");
		}
	}
	// Cada vez que se mueve
	if (event.type == SDL_MOUSEMOTION) {
		swab->x = motionX-swab->width*0.4;
		swab->y = motionY+swab->height*0.1;
	}
}

void AnaliticLayer::keysToControls(SDL_Event event) {
	if (event.type == SDL_KEYDOWN) {
		int code = event.key.keysym.sym;
		// Pulsada
		switch (code) {
		case SDLK_ESCAPE:
			game->loopActive = false;
			break;
		}
	}
	if (event.type == SDL_KEYUP) {
		int code = event.key.keysym.sym;
		// Levantada
		switch (code) {
		}
	}
}