#include "ScannerLayer.h"

ScannerLayer::ScannerLayer(Game* game, bool ilegalItem)
	: Layer(game) {
	bodyParts.clear();

	if (ilegalItem) {
		ilegalItemPosition = rand() % 7;
	}

	init();
}

void ScannerLayer::init() {
	background = new Background("res/fondoEscaner.png", WIDTH * 0.5, HEIGHT * 0.5, game);
	
	audioNothing = Audio::createAudio("res/xray_bueno.wav", false);
	audioDetected = Audio::createAudio("res/xray_malo.wav", false);

	scannerPhoto = new Actor("res/escaner.png",
		WIDTH * 0.5, HEIGHT * 0.5, 767, 767, game);

	back = new Text("Volver", WIDTH * 0.9, HEIGHT * 0.9, game);
	backButton = new Actor("res/gris.png",
		WIDTH * 0.9, HEIGHT * 0.9, 180, 90, game);

	Actor* body = new Actor("res/boton_invisible.png",
		WIDTH * 0.505, HEIGHT * 0.365, 90, 170, game);
	bodyParts.push_back(body);

	Actor* leftArm1 = new Actor("res/boton_invisible.png",
		WIDTH * 0.455, HEIGHT * 0.32, 65, 75, game);
	bodyParts.push_back(leftArm1);

	Actor* leftArm2 = new Actor("res/boton_invisible.png",
		WIDTH * 0.425, HEIGHT * 0.39, 65, 75, game);
	bodyParts.push_back(leftArm2);

	Actor* rightArm1 = new Actor("res/boton_invisible.png",
		WIDTH * 0.555, HEIGHT * 0.32, 65, 75, game);
	bodyParts.push_back(rightArm1);

	Actor* rightArm2 = new Actor("res/boton_invisible.png",
		WIDTH * 0.595, HEIGHT * 0.39, 65, 75, game);
	bodyParts.push_back(rightArm2);

	Actor* leftLeg = new Actor("res/boton_invisible.png",
		WIDTH * 0.485, HEIGHT * 0.64, 40, 250, game);
	bodyParts.push_back(leftLeg);

	Actor* rightLeg = new Actor("res/boton_invisible.png",
		WIDTH * 0.525, HEIGHT * 0.64, 40, 250, game);
	bodyParts.push_back(rightLeg);
}

void ScannerLayer::draw() {
	background->draw();
	scannerPhoto->draw();

	backButton->draw();
	back->draw();

	for (auto const& actor : bodyParts) {
		actor->draw();
	}

	SDL_RenderPresent(game->renderer);
}

void ScannerLayer::processControls() {
	// obtener controles
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		// Cambio autom�tico de input
		if (event.type == SDL_CONTROLLERBUTTONDOWN || event.type == SDL_CONTROLLERAXISMOTION) {
			game->input = game->inputGamePad;
		}
		if (event.type == SDL_KEYDOWN) {
			game->input = game->inputKeyboard;
		}
		if (event.type == SDL_MOUSEBUTTONDOWN) {
			game->input = game->inputMouse;
		}
		// Procesar teclas
		if (game->input == game->inputKeyboard) {
			keysToControls(event);
		}
		if (game->input == game->inputMouse) {
			mouseToControls(event);
		}

	}
}

void ScannerLayer::keysToControls(SDL_Event event) {
	if (event.type == SDL_KEYDOWN) {
		int code = event.key.keysym.sym;
		// Pulsada
		switch (code) {
		case SDLK_ESCAPE:
			game->loopActive = false;
			break;
		}
	}
	if (event.type == SDL_KEYUP) {
		int code = event.key.keysym.sym;
		// Levantada
		switch (code) {
		}
	}
}

void ScannerLayer::mouseToControls(SDL_Event event) {
	// Modificaci�n de coordenadas por posible escalado
	float motionX = event.motion.x / game->scaleLower;
	float motionY = event.motion.y / game->scaleLower;

	// Cada vez que hacen click
	if (event.type == SDL_MOUSEBUTTONDOWN) {
		if (backButton->containsPoint(motionX, motionY)) {
			game->layer = game->gameLayer;
		}
		int position = 0;
		for (auto const& actor : bodyParts) {
			if (actor->containsPoint(motionX, motionY) && position == ilegalItemPosition) {
				audioDetected->play();
			}
			else if (actor->containsPoint(motionX, motionY)) {
				audioNothing->play();
			}
			position++;
		}
	}
}
