#pragma once

#include "Game.h"

class Person
{
public:
	Person(string nombre, int age, bool gender, int weight, bool ilegalItem,
		bool drugs, std::tm date);
	string toString();

	string name;
	int age;
	bool gender;
	int weight;
	bool ilegalItem;
	bool drugs;
	std::tm date;
};


