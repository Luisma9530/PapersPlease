#pragma once

#include "Layer.h"
#include "Background.h"

#include "Text.h"
#include "PersonGenerator.h"

#include "ScannerLayer.h"
#include "AnaliticLayer.h"

#include "Audio.h"

#include <fstream> // Leer ficheros
#include <sstream> // Leer l�neas / String
#include <list>
#include <chrono>

class GameLayer : public Layer
{
public:
	GameLayer(Game* game);
	void init() override;
	void processControls() override;
	void update() override;
	void updatePerson();
	void draw() override;
	void keysToControls(SDL_Event event);
	void mouseToControls(SDL_Event event); // USO DE MOUSE
	Actor* message;
	bool pause;
	PersonGenerator* generator;
	bool reviewCompleted;

	Audio* audioBackground;
	Background* background;
	Text* textName;
	Text* textAge;
	Text* textGender;
	Text* textWeight;
	Text* textDate;
	Text* today;
	Actor* marco;
	Actor* photo;

	Text* accept;
	Actor* acceptButton;
	Text* deny;
	Actor* denyButton;
	Text* scanner;
	Actor* scannerButton;
	Text* drugTest;
	Actor* drugTestButton;

	Text* textRealWeight;

	Text* successes;
	Text* wrong;
	int points = 0;
	int fails = 0;;

	bool controlContinue = false;
};

