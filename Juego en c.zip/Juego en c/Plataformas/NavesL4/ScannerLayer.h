#pragma once
#include "Layer.h"

#include "Background.h"
#include "Actor.h"
#include "Text.h"
#include "Audio.h"

#include <list>

class ScannerLayer : public Layer
{
public:
	ScannerLayer(Game* game, bool ilegalItem);
	void init() override;
	void draw() override;
	void processControls() override;
	void mouseToControls(SDL_Event event);
	void keysToControls(SDL_Event event);

	Background* background;
	Actor* scannerPhoto;
	list<Actor*> bodyParts;
	Audio* audioNothing;
	Audio* audioDetected;

	int ilegalItemPosition = -1;

	Text* back;
	Actor* backButton;
};

