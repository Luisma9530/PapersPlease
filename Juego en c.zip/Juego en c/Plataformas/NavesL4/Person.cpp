#include "Person.h"

Person::Person(string nombre, int age, bool gender, int weight, bool ilegalItem,
	bool drugs, std::tm date) {
	this->name = nombre;
	this->age = age;
	this->gender = gender;
	this->weight = weight;
	this->ilegalItem = ilegalItem;
	this->drugs = drugs;
	this->date = date;
}

string Person::toString() {
	string texto = "Nombre: " + name + "\n"
		+ "Edad: " + std::to_string(age) + "\n";

	if (gender) {
		texto = texto +
			"Genero: M";
	}
	else {
		texto = texto +
			"Genero: F";
	}

	texto = texto +
		"Peso: " + std::to_string(weight) + "\n";

	return texto;
}